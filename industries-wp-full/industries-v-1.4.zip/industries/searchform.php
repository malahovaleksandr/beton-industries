<div class="sidebar_search">
    <form action="<?php echo esc_url(home_url('/')); ?>" method="get">
        <input type="text" name="s" placeholder="<?php esc_html_e('Search....', 'industries');?>">
        <button class="tran3s color1_bg"><i class="fa fa-search" aria-hidden="true"></i></button>
    </form>
</div> <!-- End of .sidebar_styleOne -->


