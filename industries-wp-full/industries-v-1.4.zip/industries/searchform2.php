<form action="<?php echo esc_url(home_url('/')); ?>" method="get" class="">
						<input type="text" name="s" placeholder="<?php esc_html_e('Search...', 'industries');?>">
						<button><i class="fa fa-search"></i></button>
					</form>


